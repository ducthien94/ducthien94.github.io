function changeLogo() {
	
	let logo = document.getElementsByTagName('img')[0].src = "https://www-impraise-com-resources.s3.amazonaws.com/uploads/logos/_600x60_fit_center-center_82_none/Impraise_Logo-Orange.png";

}
changeLogo();